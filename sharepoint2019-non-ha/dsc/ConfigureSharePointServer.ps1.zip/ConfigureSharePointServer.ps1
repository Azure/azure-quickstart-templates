#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSharePointServer
{
    param
    (
        [Parameter(Mandatory)]
        [String]
        $DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]
        $Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]
        $SharePointSetupUserAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]
        $SharePointFarmAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]
        $SharePointFarmPassphrasecreds,

        [parameter(Mandatory)]
        [String]
        $DatabaseName,

        [parameter(Mandatory)]
        [String]
        $AdministrationContentDatabaseName,

        [parameter(Mandatory)]
        [String]
        $DatabaseServer
    )

    [System.Management.Automation.PSCredential]$DomainCreds  = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$FarmCreds    = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointFarmAccountcreds.UserName)", $SharePointFarmAccountcreds.Password)
    [System.Management.Automation.PSCredential]$SPsetupCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointSetupUserAccountcreds.UserName)", $SharePointSetupUserAccountcreds.Password)

    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory
    Import-DSCResource -ModuleName SharePointDSC -ModuleVersion 3.1.0.0

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode  = "ApplyOnly"
            RebootNodeIfNeeded = $true
        }

        xWaitForADDomain DscForestWait
        {
            DomainName           = $DomainName
            DomainUserCredential = $DomainCreds
            RetryCount           = 30
            RetryIntervalSec     = 60
        }

        xComputer DomainJoin
        {
            Name       = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn  = "[xWaitForADDomain]DscForestWait"
        }

        xADUser CreateSetupAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName                    = $DomainName
            UserName                      = $SharePointSetupUserAccountcreds.UserName
            Password                      = $SharePointSetupUserAccountcreds
            Ensure                        = "Present"
            DependsOn                     = "[xComputer]DomainJoin"
        }

        Group AddSetupUserAccountToLocalAdminsGroup
        {
            GroupName        = "Administrators"
            Credential       = $DomainCreds
            MembersToInclude = "${DomainName}\$($SharePointSetupUserAccountcreds.UserName)"
            Ensure           = "Present"
            DependsOn        = "[xAdUser]CreateSetupAccount"
        }

        xADUser CreateFarmAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName                    = $DomainName
            UserName                      = $SharePointFarmAccountcreds.UserName
            Password                      = $FarmCreds
            Ensure                        = "Present"
            DependsOn                     = "[xComputer]DomainJoin"
        }

        SPFarm SharePointFarm
        {
            IsSingleInstance         = "Yes"
            RunCentralAdmin          = $true
            ServerRole               = "SingleServerFarm"
            FarmConfigDatabaseName   = $DatabaseName
            DatabaseServer           = $DatabaseServer
            FarmAccount              = $SharePointFarmAccountcreds
            Passphrase               = $SharePointFarmPassphrasecreds
            AdminContentDatabaseName = $AdministrationContentDatabaseName
            Ensure                   = "Present"
            PsDscRunAsCredential     = $SharePointSetupUserAccountcreds
        }
    }
}
