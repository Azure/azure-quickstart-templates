﻿#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration PrepareSharePointServer
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DNSServer,
        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )

    Import-DscResource -ModuleName xComputerManagement, xDisk,cDisk,xNetworking,xWindowsUpdate
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
	xHotfix FixCredSSP
        { 
            Ensure = "Present" 
            Path = "http://download.windowsupdate.com/c/msdownload/update/software/secu/2018/04/windows8.1-kb4103715-x64_43bebfcb5be43876fb6a13a4eb840174ecb1790c.msu" 
            Id = "KB4103715" 
        }  
        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
 	    DependsOn = "[xHotFix]FixCredSSP"
        }
        cDiskNoRestart SPDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitforDisk]Disk2"
        }
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            DependsOn = "[cDiskNoRestart]SPDataDisk"
        }
        xDnsServerAddress DnsServerAddress
        {
            Address        = $DNSServer
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn="[WindowsFeature]ADPS"
        }
    }
}