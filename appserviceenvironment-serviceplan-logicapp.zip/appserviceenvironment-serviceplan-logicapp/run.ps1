﻿New-AzureResourceGroup -Name <ResourceGroup Name> -TemplateFile azuredeploy.json -TemplateParameterFile azuredeploy.parameters.json -Location "West Europe"
