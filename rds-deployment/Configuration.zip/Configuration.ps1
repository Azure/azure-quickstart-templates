configuration DomainJoin 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration, xActiveDirectory, xComputerManagement

    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
   
    Node localhost
    {
        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domainCreds
            DependsOn = "[WindowsFeature]ADPowershell" 
        }
   }
}



configuration Gateway
{
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds
    ) 


    Node localhost
    {
        DomainJoin DomainJoin
        {
            domainName = $domainName 
            adminCreds = $adminCreds 
        }

        WindowsFeature RDS-Gateway
        {
            Ensure = "Present"
            Name = "RDS-Gateway"
        }

        WindowsFeature RDS-Web-Access
        {
            Ensure = "Present"
            Name = "RDS-Web-Access"
        }
    }
}



configuration SessionHost
{
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds
    ) 


    Node localhost
    {
        DomainJoin DomainJoin
        {
            domainName = $domainName 
            adminCreds = $adminCreds 
        }

        WindowsFeature RDS-RD-Server
        {
            Ensure = "Present"
            Name = "RDS-RD-Server"
        }
    }
}




configuration RDSDeployment
{
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

        # Connection Broker Node Name
        [String]$connectionBroker,
        
        # Web Access Node Name
        [String]$webAccessServer,
        
        # RDSH Name
        [String]$sessionHostNamingPrefix,
        [Int]$numberOfRdshInstances = 1,

        # Collection Name
        [String]$collectionName,

        # Connection Description
        [String]$collectionDescription

    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration, xActiveDirectory, xComputerManagement, xRemoteDesktopSessionHost

   
    $localhost = [System.Net.Dns]::GetHostByName((hostname)).HostName

    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)


    if (-not $connectionBroker)
    {
        $connectionBroker = $localhost
    }

    if (-not $webAccessServer) 
    { 
        $webAccessServer = $localhost 
    }

    if ($sessionHostNamingPrefix)
    {
        $sessionHost = 0..($numberOfRdshInstances-1) | % { "$sessionHostNamingPrefix$_.$domainname"}
    }
    else
    {
        $sessionHost = $localhost
    }

    if (-not $collectionName)
    {
        $collectionName = "Session Collection"
    }

    if (-not $collectionDescription)
    {
        $collectionDescription = "A sample Session collection up in Azure"
    }


    Node localhost
    {
        DomainJoin DomainJoin
        {
            domainName = $domainName 
            adminCreds = $adminCreds 
        }

        WindowsFeature ADDSTools
        {
            Name = "RSAT-ADDS-Tools"
        } 

        WindowsFeature RSAT-RDS-Tools
        {
            Ensure = "Present"
            Name = "RSAT-RDS-Tools"
            IncludeAllSubFeature = $true
        }

        WindowsFeature RDS-Licensing
        {
            Ensure = "Present"
            Name = "RDS-Licensing"
        }

        xRDSessionDeployment Deployment
        {
            DependsOn = "[DomainJoin]DomainJoin"

            ConnectionBroker = $connectionBroker
            WebAccessServer  = $webAccessServer

            SessionHost      = $sessionHost

            PsDscRunAsCredential = $domainCreds
        }

        xRDSessionCollection Collection
        {
            DependsOn = "[xRDSessionDeployment]Deployment"

            ConnectionBroker = $connectionBroker

            CollectionName = $collectionName
            CollectionDescription = $collectionDescription
            
            SessionHost = $sessionHost

            PsDscRunAsCredential = $domainCreds
        }

<#
        xRDSessionCollectionConfiguration CollectionConfiguration
        {
            CollectionName = $collectionName
            
            TemporaryFoldersDeletedOnExit = $false
            SecurityLayer = "SSL"

            DependsOn = "[xRDSessionCollection]Collection"
        }
#>

<#
	    LocalConfigurationManager 
        {
            ActionAfterReboot = 'StopConfiguration'
        }
#>
    }
}