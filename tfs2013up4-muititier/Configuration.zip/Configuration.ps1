﻿configuration ConfigureTfs 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$TfsSetupCredential,
		
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$TfsServiceCredential,

		[Parameter(Mandatory)]
		[string]$sqlInstance = "(localhost)",

        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, cTfs

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
		LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

		xADUser TfsServiceAccount
		{
            DomainName = $DomainName 
            DomainAdministratorCredential= $Admincreds
			UserName = "tfsservice"
			Ensure = "Present"
			DependsOn="[xComputer]DomainJoin"
		}

		Group TfsSetupAdmin
		{
			GroupName = "Administrators"
			Ensure = "Present"
			MembersToInclude = "${DomainName}\$($TfsSetupCredential.UserName)"
			Credential = $Admincreds
			DependsOn="[xComputer]DomainJoin"
		}

        cTfsApplicationTier InstallTfs2013
        {
            Name = $env:COMPUTERNAME
            Ensure = "Present"
            TfsAdminCredential = $TfsAdministratorCredential
            TfsServiceAccount = "NT AUTHORITY\Network Service"
            SqlServerInstance = $sqlInstance
            FileCacheDirectory = "C:\TFS\FileCache"
            TeamProjectCollectionName = "DefaultCollection"
            DependsOn = "[xComputer]DomainJoin", "[Group]TfsSetupAdmin","[xADUser]TfsServiceAccount"
        }
   }
} 
