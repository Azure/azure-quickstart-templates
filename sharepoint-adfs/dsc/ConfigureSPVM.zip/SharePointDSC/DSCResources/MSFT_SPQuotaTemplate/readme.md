# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to configure quota templates in the farm. These settings
will be used to make sure a certain quota template exists or not. When it
exists, it will also make sure the settings are configured as specified.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the quota template is created.
