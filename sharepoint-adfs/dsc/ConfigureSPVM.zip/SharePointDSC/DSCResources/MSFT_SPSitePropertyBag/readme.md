# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to work with SharePoint Property Bags at the site
collection level. The account that runs this resource (PsDscRunAsCredential
or InstallAccount) must be a site collection administrator.

The default value for the Ensure parameter is Present. When not specifying
this parameter, the property bag is configured.
