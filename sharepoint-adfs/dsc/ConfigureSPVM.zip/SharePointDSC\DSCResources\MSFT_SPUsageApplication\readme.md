# Description

This resource provisions an instance of the usage and health monitoring service
application. The database settings are only used for initial provisioning, but
the usage settings can be changed and will be enforced as the resource is

The default value for the Ensure parameter is Present. When not specifying this
parameter, the service application is provisioned.
