# Description

This resource is used for provisioning an application pool that can be used for
service applications. The account used for the service account must already be
registered as a managed account (which can be provisioned through

The default value for the Ensure parameter is Present. When not specifying this
parameter, the service application pool is provisioned.
