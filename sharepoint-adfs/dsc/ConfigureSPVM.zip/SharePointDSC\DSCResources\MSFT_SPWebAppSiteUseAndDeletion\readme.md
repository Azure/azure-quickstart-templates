# Description

This resource is responsible for controlling the Site Use and Deletion
settings on a specific web application. You can enable or disable the Site Use
and Deletion feature, specify the amount of days after which the alerts are
being send, if sites have to be deleted automatically and if so after how many
