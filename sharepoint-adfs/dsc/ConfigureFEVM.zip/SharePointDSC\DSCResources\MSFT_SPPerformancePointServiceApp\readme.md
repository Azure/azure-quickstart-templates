# Description

This resource is responsible for creating Performance Point Service Application
instances within the local SharePoint farm. The resource will provision and
configure the Performance Point Service Application.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the service application is provisioned.
