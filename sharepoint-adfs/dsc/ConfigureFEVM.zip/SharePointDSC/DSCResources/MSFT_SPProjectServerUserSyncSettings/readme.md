# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is responsible for configuration of the user sync settings between
projects and project sites.
