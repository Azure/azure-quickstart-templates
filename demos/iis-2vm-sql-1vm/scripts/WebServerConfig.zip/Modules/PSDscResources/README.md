SAMPLE

This module has been modified by removing files that are not needed for the purpose of the sample
scenario, to demonstrate how to enable IIS features in Windows Server.