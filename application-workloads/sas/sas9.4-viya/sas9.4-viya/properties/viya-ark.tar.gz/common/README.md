# SAS Viya Administration Resource Kit (SAS Viya ARK) - Common Utility Playbooks
#
# Copyright (c) 2019, SAS Institute Inc., Cary, NC, USA.  All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
#
The common utility files in this directory are meant as includes by other playbooks and are not directly runnable.
