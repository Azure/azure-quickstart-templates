# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource will configured the supression settings for Office Online Server
(formerly known as Office Web Apps). With these setting you can specify for
which extensions should Office Online Server not be used to open the file.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the supression settings are configured.
