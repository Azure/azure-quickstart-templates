# Description

The AdfsGlobalWebContent DSC resource manages the global web content objects or the global web content object
that corresponds to the locale that you specify.
