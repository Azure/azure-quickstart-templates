# Description

This resource can be used to configure the URIs in the Authority Information
Access and Online Responder OCSP extensions of certificates issued by an
Active Directory Certificate Authority.
