# Description

The AdfsContactPerson DSC resource manages the ADFS contact information for support isssues.
