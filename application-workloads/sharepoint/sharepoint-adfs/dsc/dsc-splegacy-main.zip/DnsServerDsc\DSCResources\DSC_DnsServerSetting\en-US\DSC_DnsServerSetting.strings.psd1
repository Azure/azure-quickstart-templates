# culture="en-US"
ConvertFrom-StringData @'
    GettingDnsServerSettings     = Getting DNS Server Settings. (DSS0001)
    SetDnsServerSetting          = Setting DNS Server setting '{0}' to value '{1}'. (DSS0002)
    EvaluatingDnsServerSettings  = Evaluating the DNS Server settings. (DSS0003)
    PropertyInDesiredState       = The property '{0}' is already in desired state. (DSS0004)
    SettingsInDesiredState       = The DNS Server settings are in desired state. (DSS0005)
    UnableToParseTimeSpan        = Could not parse the value '{0}' of the property '{1}'. (DSS0006)
    RegistryPathDoesNotExist     = The registry path '{0}' does not exist. (DSS0007)
    MaximumUdpPacketSizeRemote   = Setting MaximumUdpPacketSize on a remote server ('{0}') is not supported. Please apply this change manually. (DSS0008)
    RestartingDNSServer          = Restarting the DNS Server service to apply the '{0}' parameter change. (DSS0009)
'@
