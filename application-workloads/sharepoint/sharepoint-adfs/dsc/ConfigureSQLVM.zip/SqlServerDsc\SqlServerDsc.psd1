@{
    # Script module or binary module file associated with this manifest.
    RootModule           = 'SqlServerDsc.psm1'

    # Version number of this module.
    ModuleVersion        = '16.1.0'

    # ID used to uniquely identify this module
    GUID                 = '693ee082-ed36-45a7-b490-88b07c86b42f'

    # Author of this module
    Author               = 'DSC Community'

    # Company or vendor of this module
    CompanyName          = 'DSC Community'

    # Copyright statement for this module
    Copyright            = 'Copyright the DSC Community contributors. All rights reserved.'

    # Description of the functionality provided by this module
    Description          = 'Module with DSC resources for deployment and configuration of Microsoft SQL Server.'

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion    = '5.0'

    # Minimum version of the common language runtime (CLR) required by this module
    CLRVersion           = '4.0'

    # Functions to export from this module
    FunctionsToExport    = @('Add-SqlDscNode','Add-SqlDscTraceFlag','Complete-SqlDscFailoverCluster','Complete-SqlDscImage','Connect-SqlDscDatabaseEngine','ConvertFrom-SqlDscDatabasePermission','ConvertFrom-SqlDscServerPermission','ConvertTo-SqlDscDatabasePermission','ConvertTo-SqlDscServerPermission','Disable-SqlDscAudit','Enable-SqlDscAudit','Get-SqlDscAudit','Get-SqlDscDatabasePermission','Get-SqlDscManagedComputer','Get-SqlDscManagedComputerService','Get-SqlDscServerPermission','Get-SqlDscStartupParameter','Get-SqlDscTraceFlag','Import-SqlDscPreferredModule','Initialize-SqlDscRebuildDatabase','Install-SqlDscServer','Invoke-SqlDscQuery','New-SqlDscAudit','Remove-SqlDscAudit','Remove-SqlDscNode','Remove-SqlDscTraceFlag','Repair-SqlDscServer','Set-SqlDscAudit','Set-SqlDscDatabasePermission','Set-SqlDscServerPermission','Set-SqlDscStartupParameter','Set-SqlDscTraceFlag','Test-SqlDscIsDatabasePrincipal','Test-SqlDscIsLogin','Uninstall-SqlDscServer')

    # Cmdlets to export from this module
    CmdletsToExport      = @()

    # Variables to export from this module
    VariablesToExport    = @()

    # Aliases to export from this module
    AliasesToExport      = @()

    DscResourcesToExport = @('SqlAudit','SqlDatabasePermission','SqlPermission','SqlAG','SqlAGDatabase','SqlAgentAlert','SqlAgentFailsafe','SqlAgentOperator','SqlAGListener','SqlAGReplica','SqlAlias','SqlAlwaysOnService','SqlConfiguration','SqlDatabase','SqlDatabaseDefaultLocation','SqlDatabaseMail','SqlDatabaseObjectPermission','SqlDatabaseRole','SqlDatabaseUser','SqlEndpoint','SqlEndpointPermission','SqlLogin','SqlMaxDop','SqlMemory','SqlProtocol','SqlProtocolTcpIp','SqlReplication','SqlRole','SqlRS','SqlRSSetup','SqlScript','SqlScriptQuery','SqlSecureConnection','SqlServiceAccount','SqlSetup','SqlTraceFlag','SqlWaitForAG','SqlWindowsFirewall')

    RequiredAssemblies   = @()

    # Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    PrivateData          = @{

        PSData = @{
            # Set to a prerelease string value if the release should be a prerelease.
            Prerelease   = ''

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @('DesiredStateConfiguration', 'DSC', 'DSCResourceKit', 'DSCResource')

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/dsccommunity/SqlServerDsc/blob/main/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/dsccommunity/SqlServerDsc'

            # A URL to an icon representing this module.
            IconUri      = 'https://dsccommunity.org/images/DSC_Logo_300p.png'

            # ReleaseNotes of this module
            ReleaseNotes = '## [16.1.0] - 2023-02-28

### Removed

- SqlServerDsc
  - Removed `Assert-ElevatedUser` from private functions ([issue #1797](https://github.com/dsccommunity/SqlServerDsc/issues/1797)).
    - `Assert-ElevatedUser` added to _DscResource.Common_ public functions
      ([issue #82](https://github.com/dsccommunity/DscResource.Common/issues/82)).
  - Removed `Test-IsNumericType` from private functions ([issue #1795](https://github.com/dsccommunity/SqlServerDsc/issues/1795)).
    - `Test-IsNumericType` added to _DscResource.Common_ public functions
    ([issue #87](https://github.com/dsccommunity/DscResource.Common/issues/87)).
  - Removed `Test-ServiceAccountRequirePassword` from private functions ([issue #1794](https://github.com/dsccommunity/SqlServerDsc/issues/1794)
    - Replaced by `Test-AccountRequirePassword` that was added to _DscResource.Common_
      public functions ([issue #93](https://github.com/dsccommunity/DscResource.Common/issues/93)).
  - Removed `Assert-RequiredCommandParameter` from private functions ([issue #1796](https://github.com/dsccommunity/SqlServerDsc/issues/1796)).
    - Replaced by `Assert-BoundParameter` (part of _DscResource.Common_)
      that had a new parameter set added ([issue #92](https://github.com/dsccommunity/DscResource.Common/issues/92)).
  - Removed private function `Test-ResourceDscPropertyIsAssigned` and
    `Test-ResourceHasDscProperty`. Both are replaced by `Test-DscProperty`
    which is now part of the module _DscResource.Common_.
  - Removed private function `Get-DscProperty`. It is replaced by `Get-DscProperty`
    which is now part of the module _DscResource.Common_.
  - The class `ResourceBase` and `Reason` has been removed, they are now
    part of the module _DscResource.Base_.
  - The enum `Ensure` has been removed, is is now part of the module
    _DscResource.Base_.
  - The private functions that the class `ResourceBase` depended on has been
    moved to the module _DscResource.Base_.
    - `ConvertFrom-CompareResult`
    - `ConvertTo-Reason`
    - `Get-ClassName`
    - `Get-LocalizedDataRecursive`
  - Added documentation how to generate stub modules for the unit tests.
    The documentation can be found in [''tests/Unit/Stubs`](https://github.com/dsccommunity/SqlServerDsc/tree/main/tests/Unit/Stubs).
  - SqlRSSetup and SqlRS
    - Removed the integration test when running against SQL Server 2019,
      due to the URL to download the Reporting Services 2019 executable
      no longer works.

### Added

- SqlServerDsc
  - The following private functions were added to the module (see comment-based
    help for more information):
    - `Assert-SetupActionProperties`
    - `Invoke-SetupAction`
    - `ConvertTo-ManagedServiceType`
    - `ConvertFrom-ManagedServiceType`
    - `Assert-ManagedServiceType`
  - The following public functions were added to the module (see comment-based
    help for more information):
    - `Install-SqlDscServer`
    - `Uninstall-SqlDscServer`
    - `Add-SqlDscNode`
    - `Remove-SqlDscNode`
    - `Repair-SqlDscServer`
    - `Complete-SqlDscImage`
    - `Complete-SqlDscFailoverCluster`
    - `Initialize-SqlDscRebuildDatabase`
    - `Import-SqlDscPreferredModule`
    - `Get-SqlDscManagedComputer`
    - `Get-SqlDscManagedComputerService`
    - `Get-SqlDscTraceFlag`
    - `Add-SqlDscTraceFlag`
    - `Remove-SqlDscTraceFlag`
    - `Set-SqlDscTraceFlag`
    - `Get-SqlDscStartupParameter`
    - `Set-SqlDscStartupParameter`
  - Added class `StartupParameters` which can parse the startup parameters
    of a manged computer service object.
  - Added class `SqlReason` to be used as the type of the DSC property `Reasons`
    for class-based resources.
  - New GitHub issue templates for proposing new public commands, proposing
    an enhancement to an existing command, or having a problem with an existing
    command.
  - Integration tests are now also run on SQL Server 2022 and SQL Server
    Reporting Services 2022.
  - Integration tests now wait for LCM after each It-block, not just at the
    end of a Context-block. Hopefully this will mitigate some of the intermittent
    errors we have seen when running the integration tests in the pipeline.
  - Use preview version of Pester to support the development of Pester as
    this is a code base with a diverse set of tests thar can help catch
    issues in Pester. If preview release of Pester prevents release we
    should temporary shift back to stable.
  - New QA tests for public commands and private functions.
- SqlDatabase
  - Added compatibility levels for SQL Server 2022 (major version 16).
- SqlSetup
  - Paths for SQL Server 2022 are correctly returned by Get.
- SqlRS
  - Added optional parameter `Encrypt`. Parameter `Encrypt` controls whether
    the connection used by `Invoke-SqlCmd should enforce encryption. This
    parameter can only be used together with the module _SqlServer_ v22.x
    (minimum v22.0.49-preview). The parameter will be ignored if an older
    major versions of the module _SqlServer_ is used.
- SqlScript
  - Added optional parameter `Encrypt`. Parameter `Encrypt` controls whether
    the connection used by `Invoke-SqlCmd should enforce encryption. This
    parameter can only be used together with the module _SqlServer_ v22.x
    (minimum v22.0.49-preview). The parameter will be ignored if an older
    major versions of the module _SqlServer_ is used.
- SqlScriptQuery
  - Added optional parameter `Encrypt`. Parameter `Encrypt` controls whether
    the connection used by `Invoke-SqlCmd should enforce encryption. This
    parameter can only be used together with the module _SqlServer_ v22.x
    (minimum v22.0.49-preview). The parameter will be ignored if an older
    major versions of the module _SqlServer_ is used.
- SqlTraceFlag
  - The resource is now tested with an integration tests ([issue #1835](https://github.com/dsccommunity/SqlServerDsc/issues/1835)).
  - A new parameter `ClearAllTraceFlags` was added so a configuration
    can enforce that there should be no trace flags.
- The public commands `Add-SqlDscNode`, `Complete-SqlDscFailoverCluster`,
  `Complete-SqlDscImage`, `Install-SqlDscServer`, and `Repair-SqlDscServer`
  now support the setup argument `ProductCoveredBySA` ([issue #1798](https://github.com/dsccommunity/SqlServerDsc/issues/1798)).

### Changed

- SqlServerDsc
  - Update Stale GitHub Action to v7.
  - Update to build module in separate folder under `output`.
  - Moved the build step of the pipeline to a Windows build worker when
    running in Azure DevOps.
  - Class-based resources now uses the parent class `ResourceBase` from the
    module _DscResource.Base_ ([issue #1790](https://github.com/dsccommunity/SqlServerDsc/issues/1790)).
  - Settings for the _Visual Studio Code_ extension _Pester Tests_ was changed
    to be able to run all unit tests, and all tests run by the extension
    are now run in a separate process to be able to handle changes in
    class-based resources.
  - The AppVeyor configuration file was updated to include the possibility
    to run integration tests for SQL Server 2022.
  - The AppVeyor configuration file was updated to include the possibility
    to run skip installing one or more SQL Server instances when debugging
    in AppVeyor to help maximize the time alloted be run.
  - The stubs in `SqlServerStub.psm1` are now based on the commands from the
    module SqlServer v22.0.49-preview.
  - The module will now call `Import-SqlDscPreferredModule` when the module
    is imported to make sure SqlServer (default preferred module) or SQLPS
    is loaded into the session. This will make it possible for classes and
    commands to use and return SQL types. If no module is found it will
    output a warning to install any of the dependent modules.
  - Add empty constructor to classes to be able to use Pester''s new code
    coverage method. See more information can be found in [pester/Pester#2306](https://github.com/pester/Pester/issues/2306).
  - The type of the property `Reasons` was changed in the class-based resources.
    This resolves a problem when using two DSC resource modules that was
    using the same class-type for the property `Reasons`. Resolves the issues
    [issue #1831](https://github.com/dsccommunity/SqlServerDsc/issues/1831),
    [issue #1832](https://github.com/dsccommunity/SqlServerDsc/issues/1832),
    and [issue #1833](https://github.com/dsccommunity/SqlServerDsc/issues/1833).
- `Install-SqlServerDsc`
  - No longer throws an exception when parameter `AgtSvcAccount` is not specified.
- SqlAgReplica
  - Converted unit test to Pester 5.
  - `Update-AvailabilityGroupReplica` to trigger once within `Set-TargetResource`
    for all AvailabilityReplica changes.
- Private function `Invoke-SetupAction` ([issue #1798](https://github.com/dsccommunity/SqlServerDsc/issues/1798)).
  - Was changed to support the SQL Server 2022 GA feature `AzureExtension`
    (that replaced the feature name `ARC`).
  - Support the setup argument `ProductCoveredBySA`.
  - No longer supports the argument `OnBoardSQLToARC` as it was removed in
    SQL Server 2022 GA.
- `Install-SqlDscServer`
  - Was changed to support the SQL Server 2022 GA feature `AzureExtension`
    (that replaced the feature name `ARC`) ([issue #1798](https://github.com/dsccommunity/SqlServerDsc/issues/1798)).
- `Uninstall-SqlDscServer`
  - Was changed to support the SQL Server 2022 GA feature `AzureExtension`
    (that replaced the feature name `ARC`) ([issue #1798](https://github.com/dsccommunity/SqlServerDsc/issues/1798)).
  - Now support the argument `SuppressPrivacyStatementNotice` ([issue #1809](https://github.com/dsccommunity/SqlServerDsc/issues/1809)).
- `Import-SqlDscPreferredModule`
  - No longer tries to get the environment variables from the machine state
    when run on Linux or macOS. Th'

        } # End of PSData hashtable

    } # End of PrivateData hashtable
}
