#
# Copyright="?Microsoft Corporation. All rights reserved."
#

param (
	[Parameter(Mandatory)]
    [string]$AzureUsername,
	[Parameter(Mandatory)]
    [string]$AzurePassword,
	[string]$AdResourceID = "",
	[Parameter(Mandatory)]
	[string]$TenantId,
	[Parameter(Mandatory)]
	[string]$VMName,
	[Parameter(Mandatory)]
	[int32]$VMCount,
	[Parameter(Mandatory)]
	[string]$AzureStorageAccount,
	[Parameter(Mandatory)]
	[string]$AzureStorageAccessKey
)

function VMBootAll {
	
	# Azure uses AzureAdApplicationId and AzureAdApplicationPassword values as AzureUserName and AzurePassword parameters respectively
	# AzureStack uses tenant UserName and Password values as AzureUserName and AzurePassword parameters respectively
	$azureUsername = $AzureUsername;
	$azurePassword = $AzurePassword;
	# Azure uses "null" or "" blank value, AzureStack uses "https://azurestack.local-api/" value for AdResourceID parameter
    $adResourceID = $AdResourceID;
	$tenant = $TenantId;
	$vmName = $VMName;
	$vmCount = $VMCount;
	$storageAccountName = $AzureStorageAccount;
	$storageAccountKey = $AzureStorageAccessKey;

	# Local file storage location
	$localPath = "$env:SystemDrive";

	# Log file
	$logFileName = "VMWorkloadController.log.ps1";
	$logFilePath = "$localPath\$logFileName";
	
	# Turn off private firewall
	netsh advfirewall set privateprofile state off;
	
	# PS Credentials
	$pw = ConvertTo-SecureString -AsPlainText -Force -String $azurePassword;
	$pscred = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $azureUsername,$pw;
	if($pscred -eq $null) {
		Write-Host "Powershell Credential object is null. Cannot proceed.";
		return;
	}
	$azureCreds = Get-Credential -Credential $pscred;
	if($azureCreds -eq $null) {
		Write-Host "Get-Credential returned null. Cannot proceed.";
		return;
	}
	
	######################
	### AZURE RM SETUP ###
	######################
	# AzureStack
	if($adResourceID -ne "")
	{
		# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
		add-type @"
		using System.Net;
		using System.Security.Cryptography.X509Certificates;
		public class TrustAllCertsPolicy : ICertificatePolicy {
			public bool CheckValidationResult(
				ServicePoint srvPoint, X509Certificate certificate,
				WebRequest request, int certificateProblem) {
				return true;
			}
		}
"@
		[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
		Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

		# Download AzureStack Powershell SDK - https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi 
		$azureStackPSMsi = "https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi"
		$dest = Join-Path $env:SystemDrive "AzureStack"
		$path = Join-Path $dest "azure-powershell.1.2.0.msi"
		if(Test-Path $dest){
			Write-Verbose "Skipped downloading file $azureStackPSMsi"
		}
		else {
			try {
				New-Item $dest -ItemType Directory -Force -Confirm:0
				$wc = New-Object System.Net.WebClient
				$wc.DownloadFile($azureStackPSMsi, $path)
			} catch {
				Write-Error "Exception in downloading Azure Stack Powershell SDK."
			}
		}

		# Install AzureStack Powershell SDK
		$azureStackSdkPath = Join-Path ${env:ProgramFiles(x86)} "Microsoft SDKs\Azure";
		if((Test-Path $azureStackSdkPath) -eq $false){
			$arguments = "/quiet /qn /passive"
			$process = Start-Process -FilePath $path -ArgumentList $arguments -Wait -PassThru
			if ($process.ExitCode -gt 0 -and $process.ExitCode -ne 3010) {
				Write-Error "Installer operation $path $arguments failed with exit code $($process.ExitCode)!"
			} elseif ($process.ExitCode -eq -2145124329){
				Write-Warning "Installer operation is not applicable/needed."
			} else {
				Write-Verbose "Installer operation $path $arguments completed successfully."
			}
		}
				
		# Import Azure Resource Manager PS module if already present
		try {
			Write-Host "Importing Azure RM";
			Import-Module Azure -ErrorAction Stop | Out-Null;
		} catch {
			Write-Error "Cannot import Azure RM module. Cannot proceed further without Azure RM module.";
			return;
		}
	}
	# Azure Cloud
	else {
		# Import Azure Resource Manager PS module if already present
		try {
			Write-Host "Importing Azure RM";
			Import-Module Azure -ErrorAction Stop | Out-Null;
			Import-Module AzureRM -ErrorAction Stop | Out-Null;
		}
		# Install Azure Resource Manager PS module
		catch {
			# Suppress prompts
			$ConfirmPreference = 'None';
			Write-Error "Cannot import Azure RM module, proceeding with installation";

			# Install AzureRM
			try {
				Get-PackageProvider -Name nuget -ForceBootstrap �Force | Out-Null;
				Install-Module Azure �repository PSGallery �Force -Confirm:0 | Out-Null;
				Install-Module AzureRM �repository PSGallery �Force -Confirm:0 | Out-Null;
			}
			catch {
				Write-Error "Installation of Azure RM module failed."
			}

			# Import AzureRM
			try {
				Import-Module Azure -ErrorAction Stop | Out-Null;
				Import-Module AzureRM -ErrorAction Stop | Out-Null;
			} catch {
				Write-Error "Cannot import Azure RM module. Cannot proceed further without Azure RM module.";
				return;
			}
		}
	}

    # AzureStack
	if($adResourceID -ne "")
	{
		# Authenticate to AzureStack
		Add-AzureRmEnvironment -Name 'AzureStack' -ActiveDirectoryEndpoint ("https://login.windows.net/$tenant/") -ActiveDirectoryServiceEndpointResourceId $adResourceID `
			-ResourceManagerEndpoint ("https://api.azurestack.local/") -GalleryEndpoint ("https://gallery.azurestack.local:30016/") -GraphEndpoint "https://graph.windows.net/" -StorageEndpoint "azurestack.local";
		if($azureCreds -eq $null) {
			Write-Host "Powershell Credential object is null. Cannot proceed." -ForegroundColor Red;
			"Powershell Credential object is null. Cannot proceed." | Out-File $logFilePath -Encoding ASCII -Append;
			return;
		}
		$azureAcc = Add-AzureRmAccount -EnvironmentName 'AzureStack' -Verbose -Credential $azureCreds;
	}
	# AzureCloud
	else {
		# Authenticate to Azure using AzureAdApplication
		if($azureCreds -eq $null) {
			Write-Host "Powershell Credential object is null. Cannot proceed." -ForegroundColor Red;
			"Powershell Credential object is null. Cannot proceed." | Out-File $logFilePath -Encoding ASCII -Append;
			return;
		}
		"Authenticating Azure RM account to get VMs" | Out-File $logFilePath -Encoding ASCII -Append;
		Add-AzureRmAccount -Credential $azureCreds -ServicePrincipal -Tenant $tenant;
	}
	
	##############################
	### VM PRE-BOOTSTORM SETUP ###
	##############################
	# Get VMs
	"Getting VMs" | Out-File $logFilePath -Encoding ASCII -Append;
	$vms = Get-AzureRmVM | Where {$_.Name -match $vmName}

	# Wait timeout retry count
	$numberOfRetries = 10

	# Wait for all VMs are deployed
	$noOfRetries = $numberOfRetries
	$noOfDeployedVMs = 0
	while(($noOfRetries -gt 0) -and ($noOfDeployedVMs -lt $vmCount)) {
		Start-Sleep -Seconds 120
		$noOfDeployedVMs = 0
		Write-Host "Getting VMs. Retry # $noOfRetries";
		"Getting VMs. Retry # $noOfRetries" | Out-File $logFilePath -Encoding ASCII -Append;
		$vms = Get-AzureRmVM | Where {$_.Name -match $vmName}
		foreach($vm in $vms) {
			# All VMs except jump box VM
			if($vm.Name -match "[0-9]$") {
				$noOfDeployedVMs += 1
			}
		}
		$noOfRetries -= 1
	}
	if($noOfDeployedVMs -lt $vmCount) {
		Write-Host "Only $noOfDeployedVMs out of $vmCount user requested VMs are deployed." -ForegroundColor Yellow;
		"Only $noOfDeployedVMs out of $vmCount user requested VMs are deployed." | Out-File $logFilePath -Encoding ASCII -Append;
	}
	else {
		Write-Host "All $noOfDeployedVMs out of $vmCount user requested VMs are deployed." -ForegroundColor Green;
		"All $noOfDeployedVMs out of $vmCount user requested VMs are deployed." | Out-File $logFilePath -Encoding ASCII -Append;
	}

	$resourceGroupName = $null
	# Turn off all VMs (except jump box VM which stores results)
	foreach($vm in $vms) {
		$_vmName = $vm.Name;
		# All VMs except jump box VM
		if($_vmName -match "[0-9]$") {
			$_date = Get-Date -Format hh:mmtt
			Write-Host "Turning off VM $_vmName in parallel at $_date" -F Yellow
			"Turning off VM $_vmName in parallel at $_date" | Out-File $logFilePath -Encoding ASCII -Append;
			Start-Job -ScriptBlock {
				param($_vmName,$_resourceGroupName,$adResourceID,$tenant,$azureUsername,$azurePassword)

				# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
				add-type @"
				using System.Net;
				using System.Security.Cryptography.X509Certificates;
				public class TrustAllCertsPolicy : ICertificatePolicy {
					public bool CheckValidationResult(
						ServicePoint srvPoint, X509Certificate certificate,
						WebRequest request, int certificateProblem) {
						return true;
					}
				}
"@
				[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
				Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

				$pw = ConvertTo-SecureString -AsPlainText -Force -String $azurePassword;
				$pscred = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $azureUsername,$pw;
				if($pscred -eq $null) {
					Write-Host "Powershell Credential object is null. Cannot proceed.";
					return;
				}
				$azureCreds = Get-Credential -Credential $pscred;

				# AzureStack
				if($adResourceID -ne "")
				{
					# Authenticate to AzureStack
					Add-AzureRmEnvironment -Name 'AzureStack' -ActiveDirectoryEndpoint ("https://login.windows.net/$tenant/") -ActiveDirectoryServiceEndpointResourceId $adResourceID `
						-ResourceManagerEndpoint ("https://api.azurestack.local/") -GalleryEndpoint ("https://gallery.azurestack.local:30016/") -GraphEndpoint "https://graph.windows.net/" -StorageEndpoint "azurestack.local";
					if($azureCreds -eq $null) {
						Write-Host "Powershell Credential object is null. Cannot proceed.";
						"Powershell Credential object is null. Cannot proceed." | Out-File $logFilePath -Encoding ASCII -Append;
						return;
					}
					$azureAcc = Add-AzureRmAccount -EnvironmentName 'AzureStack' -Verbose -Credential $azureCreds;
				}
				# AzureCloud
				else {
					# Authenticate to Azure using AzureAdApplication
					if($azureCreds -eq $null) {
						Write-Host "Powershell Credential object is null. Cannot proceed.";
						"Powershell Credential object is null. Cannot proceed." | Out-File $logFilePath -Encoding ASCII -Append;
						return;
					}
					"Authenticating Azure RM account to stop VMs in parallel" | Out-File $logFilePath -Encoding ASCII -Append;
					Add-AzureRmAccount -Credential $azureCreds -ServicePrincipal -Tenant $tenant;
				}

				Stop-AzureRmVM -Name $_vmName -ResourceGroupName $_resourceGroupName -Force;

			} -ArgumentList $vm.Name,$vm.ResourceGroupName,$adResourceID,$tenant,$azureUsername,$azurePassword | Out-Null;
			$resourceGroupName = $vm.ResourceGroupName
		}
	}
	# Wait for background jobs
	$jobs = Get-Job | ? {$_.State -eq "Running"}
	while($jobs.Count -gt 0)
	{
		Start-Sleep -Seconds 15
		$jobs = Get-Job | ? {$_.State -eq "Running"}
	}

	# Clear background jobs
	Get-Job | Remove-Job -Force -Confirm:0

	# Check if all VMs are deallocated (i.e. turned off)
	$noOfRetries = $numberOfRetries
	$noOfRunningVMs = [int32]::MaxValue
	while(($noOfRetries -gt 0) -and ($noOfRunningVMs -gt 0)) {
		Start-Sleep -Seconds 120
		$noOfRunningVMs = 0
		foreach($vm in $vms) {
			# All VMs except jump box VM
			if($vm.Name -match "[0-9]$") {
				$vmStatus = Get-AzureRmVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Status
				$isVmRunning = $vmStatus.Statuses[1].Code.Contains("running")
				if($isVmRunning -eq $true){
					$noOfRunningVMs += 1
				}
			}
		}
		$noOfRetries -= 1
	}
	if($noOfRunningVMs -gt 0) {
		Write-Host "$noOfRunningVMs out of $vmCount VMs failed to turn off." -ForegroundColor Yellow;
		"$noOfRunningVMs out of $vmCount VMs failed to turn off." | Out-File $logFilePath -Encoding ASCII -Append;
	}
	else {
		Write-Host "All $vmCount VMs are turned off";
		"All $vmCount VMs are turned off" | Out-File $logFilePath -Encoding ASCII -Append;
	}

	####################
	### VM BOOTSTORM ###
	####################
	# Boot all VMs at the same time
	foreach($vm in $vms) {
		$_vmName = $vm.Name;
		# All VMs except jump box VM
		if($_vmName -match "[0-9]$") {
			$_date = Get-Date -Format hh:mmtt
			Write-Host "Booting VM $_vmName at $_date" -F Yellow
			"Booting VM $_vmName at $_date" | Out-File $logFilePath -Encoding ASCII -Append;

			Start-Job -ScriptBlock {
				param($_vmName,$_resourceGroupName,$adResourceID,$tenant,$azureUsername,$azurePassword,$logFilePath)

				# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
				add-type @"
				using System.Net;
				using System.Security.Cryptography.X509Certificates;
				public class TrustAllCertsPolicy : ICertificatePolicy {
					public bool CheckValidationResult(
						ServicePoint srvPoint, X509Certificate certificate,
						WebRequest request, int certificateProblem) {
						return true;
					}
				}
"@
				[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
				Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

				$pw = ConvertTo-SecureString -AsPlainText -Force -String $azurePassword;
				$pscred = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $azureUsername,$pw;
				if($pscred -eq $null) {
					Write-Host "Unable to create PSCrednetial using user provided credentials. Cannot proceed.";
					"Unable to create PSCrednetial using user provided credentials. Cannot proceed." | Out-File $logFilePath -Encoding ASCII -Append;
					return;
				}
				$azureCreds = Get-Credential -Credential $pscred;
				if($azureCreds -eq $null) {
					Write-Host "Unable to create crednetial object using user provided credentials. Cannot proceed.";
					"Unable to create crednetial object using user provided credentials. Cannot proceed." | Out-File $logFilePath -Encoding ASCII -Append;
					return;
				}

                # AzureStack
				if($adResourceID -ne "")
				{
					# Authenticate to AzureStack using Azure Account crednetials and given tenantID, resourceID
					Add-AzureRmEnvironment -Name 'AzureStack' -ActiveDirectoryEndpoint ("https://login.windows.net/$tenant/") -ActiveDirectoryServiceEndpointResourceId $adResourceID `
						-ResourceManagerEndpoint ("https://api.azurestack.local/") -GalleryEndpoint ("https://gallery.azurestack.local:30016/") -GraphEndpoint "https://graph.windows.net/" -StorageEndpoint "azurestack.local";
					$azureAcc = Add-AzureRmAccount -EnvironmentName 'AzureStack' -Verbose -Credential $azureCreds;
				}
				# AzureCloud
				else {
					# Authenticate to Azure using AzureAdApplication and given tenantID
					"Authenticating Azure RM account to start VMs in parallel" | Out-File $logFilePath -Encoding ASCII -Append;
					$azureAcc = Add-AzureRmAccount -Credential $azureCreds -ServicePrincipal -Tenant $tenant;
				}

				# Get VM Boot Start Time
				$_statusBootStartTime = Get-Date;

				Start-AzureRmVM -Name $_vmName -ResourceGroupName $_resourceGroupName;

				# Get VM Boot End Time (Ignore NULL values of Time)
				$_statusBootEndTime = (Get-AzureRmVm -Name $_vmName -ResourceGroupName $_resourceGroupName -Status).Statuses | Select Time | ? {$_.Time -ne $null};

				# Create custom vm boot result object
				$_vmBootResult = "" | Select-Object VMName, VMBootStartTime, VMBootEndTime, VMBootTimeInSeconds;
				$_vmBootResult.VMName = ($_vmName).Trim();
				$_vmBootResult.VMBootStartTime = ([DateTimeOffset]$_statusBootStartTime).DateTime;
				$_vmBootResult.VMBootEndTime = ([DateTimeOffset]$_statusBootEndTime.Time.DateTime).DateTime;
				$dbgText = "DEBUG: VM $_vmName boot start time: " + $_vmBootResult.VMBootStartTime + ", boot end time: " + $_vmBootResult.VMBootEndTime;
				$dbgTest | Out-File $logFilePath -Encoding ASCII -Append;
				$_vmBootResult.VMBootTimeInSeconds = [float]($_vmBootResult.VMBootEndTime - $_vmBootResult.VMBootStartTime).TotalSeconds;
				return $_vmBootResult;

			} -ArgumentList $vm.Name,$vm.ResourceGroupName,$adResourceID,$tenant,$azureUsername,$azurePassword,$logFilePath | Out-Null;
		}
	}
	
	# Wait for background jobs
	$jobs = Get-Job | ? {$_.State -eq "Running"}
	while($jobs.Count -gt 0)
	{
		Start-Sleep -Seconds 15
		$jobs = Get-Job | ? {$_.State -eq "Running"}
	}

	# Receive job results
	$vmbootResults = @()
	foreach($job in Get-Job) { $vmbootResults += ,(Receive-Job -Job $job) }

	# Clear background jobs
	Get-Job | Remove-Job -Force -Confirm:0

	# Prepare storage context to upload results to Azure storage table
	$storageEndpoint = "core.windows.net";
	# AzureStack
	if($adResourceID -ne "")
	{
		$storageEndpoint = "azurestack.local";
	}
	# Azure Cloud
	else {
		$storageEndpoint = "core.windows.net";
	}
	"Azure storage endpoint $storageEndpoint is being used." | Out-File $logFilePath -Encoding ASCII -Append;
	$storageContext = $null;
	$storageTable = $null;
	try {
		$storageContext = New-AzureStorageContext $storageAccountName -StorageAccountKey $storageAccountKey -Endpoint $storageEndpoint;
		if($storageContext -eq $null){
			"Azure Storage context is null." | Out-File $logFilePath -Encoding ASCII -Append;
		}
		$storageTableName = "VMBootResults"

		# Retrieve the table if it already exists.
		try {
			$storageTable = Get-AzureStorageTable �Name $storageTableName -Context $storageContext -ErrorAction SilentlyContinue;
			if($storageTable -ne $null)
			{
				Remove-AzureStorageTable -Name $storageTableName -Context $storageContext -Force -ErrorAction SilentlyContinue;
			}
		} catch { 
			Write-Verbose "Storage table $storageTableName does not exists. Creating a new table.";
			"Storage table $storageTableName does not exists. Creating a new table." | Out-File $logFilePath -Encoding ASCII -Append;
		}
		
		#Create a new table if it does not exist.
		if ($storageTable -eq $null)
		{
			try {
				$storageTable = New-AzureStorageTable �Name $storageTableName -Context $storageContext;
			} catch { 
				Write-Verbose "Storage table $storageTableName cannot be created.";
				"Storage table $storageTableName cannot be created." | Out-File $logFilePath -Encoding ASCII -Append;
			}
		}
	}
	catch {
		Write-Error "Azure storage context cannot be created."
		"Azure storage context cannot be created for a given storage account $storageAccountName" | Out-File $logFilePath -Encoding ASCII -Append;
	}

	# Function to add a result row to the Azure Storage Table
	function Add-TableEntity() {
        [CmdletBinding()]
        param(
			$table,
			[String]$PartitionKey,
			[String]$RowKey,
			[String]$Value
        )

		if($table -eq $null){
			Write-Verbose "Value cannot be inserted into null table";
			"Value cannot be inserted into null table" | Out-File $logFilePath -Encoding ASCII -Append;
		}

        $entity = New-Object -TypeName Microsoft.WindowsAzure.Storage.Table.DynamicTableEntity -ArgumentList $PartitionKey, $RowKey
        $entity.Properties.Add("Value", $Value)
		if($entity -eq $null){
			Write-Verbose "Entity cannot be created for partition key $PartitionKey and row $RowKey";
			"Entity cannot be created for partition key $PartitionKey and row $RowKey" | Out-File $logFilePath -Encoding ASCII -Append;
		}

        $result = $table.CloudTable.Execute([Microsoft.WindowsAzure.Storage.Table.TableOperation]::Insert($entity))
        return $result
    }
	
	# Display boot results
	$vmbootResultFile = "$env:SystemDrive\VMBootAllResult.log.ps1"

	if($vmbootResults.Count -gt 0) {

		Write-Host "----------------------------------------------------------"
		Write-Host "VM Name `t`tVM Boot Time (sec)"
		Write-Host "----------------------------------------------------------"

		"----------------------------------------------------------" | Out-File $vmbootResultFile -Encoding ASCII;
		"VM Name `t`tVM Boot Time (sec)" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		"----------------------------------------------------------" | Out-File $vmbootResultFile -Encoding ASCII -Append;

		$_vmBootFailedCount = 0
		$_vmBootTimeCount = 0
		$_vmBootTimeSum = 0.0
		$_vmBootTimeAvg = 0.0
		$_vmBootTimeAbsolute = 0.0
		$_vmBootTimeAbsoluteStart = Get-Date 
		$_vmBootTimeAbsoluteEnd = (Get-Date).AddDays(-30)
		$_vmBootTimeMax = 0.0
		$_vmBootTimeMin = [float]::MaxValue
		$_executionId = Get-Date -Format yyyyMMdd_HHmm

		$vmResultIndex = 0;
		foreach($vmbootResult in $vmbootResults) {
			if($vmbootResult -ne $null)
			{
				# Remove extra array object with properties Environment,Account,Tenant,Subscription,CurrentStorageAccount
				$vmbootResult = $vmbootResult | ? { $_.GetType().ToString() -contains "System.Management.Automation.PSCustomObject" }

				$_vmName = $vmbootResult.VMName
				$_vmBootTime = ([double]::Parse($vmbootResult.VMBootTimeInSeconds))
				$_vmBootTimeString = "{0:N3}" -f [float]($_vmBootTime)
				if(($_vmBootTime -le 0) -and ($_vmBootTime -ge [Int32]::MaxValue)) {
					"Skipping invalid boot time $_vmBootTimeString for VM $_vmname" | Out-File $logFilePath -Encoding ASCII -Append;
					$_vmBootFailedCount++;
					continue;
				}
				
				Write-Host "$_vmName `t`t$_vmBootTimeString"
				"$_vmName `t`t$_vmBootTime" | Out-File $vmbootResultFile -Encoding ASCII -Append;

				# Add vm boot results to the Azure storage table
				if($storageTable -ne $null){
					try {
						Add-TableEntity -Table $storageTable -PartitionKey $_executionId -RowKey $_vmName -Value $_vmBootTimeString;
					} catch {
						Write-Verbose "Adding Azure storage table entry for row $vmResultIndex failed.";
						"Adding Azure storage table entry for row $vmResultIndex failed." | Out-File $logFilePath -Encoding ASCII -Append;
					}
				}
				else {
					"Azure storage table object $storageTable is null" | Out-File $logFilePath -Encoding ASCII -Append;
				}

				$_vmBootTimeSum += $_vmBootTime
				$_vmBootTimeCount += 1
				if($_vmBootTimeAbsoluteStart -gt $vmbootResult.VMBootStartTime) {
					$_vmBootTimeAbsoluteStart = $vmbootResult.VMBootStartTime
				}
				if($_vmBootTimeAbsoluteEnd -lt $vmbootResult.VMBootEndTime) {
					$_vmBootTimeAbsoluteEnd = $vmbootResult.VMBootEndTime
				}
				if($_vmBootTimeMax -lt $_vmBootTime){
					$_vmBootTimeMax = $_vmBootTime
				}
				if($_vmBootTimeMin -gt $_vmBootTime){
					$_vmBootTimeMin = $_vmBootTime
				}
			}
			$vmResultIndex += 1;
		}

		$_vmBootTimeAvg = "{0:N3}" -f [float]($_vmBootTimeSum/$_vmBootTimeCount)
		$_vmBootTimeAbsolute = "{0:N3}" -f [float](($_vmBootTimeAbsoluteEnd - $_vmBootTimeAbsoluteStart).TotalSeconds);
		$_vmBootTimeMax = "{0:N3}" -f [float]($_vmBootTimeMax)
		$_vmBootTimeMin = "{0:N3}" -f [float]($_vmBootTimeMin)
		Write-Host "----------------------------------------------------------";
		Write-Host "$_vmBootTimeCount Azure A1-sized VMs cold booted in $_vmBootTimeAbsolute seconds at an average start time $_vmBootTimeAvg seconds/VM." -ForegroundColor Green;
		Write-Host "----------------------------------------------------------";
		Write-Host "Minimum vm boot time is $_vmBootTimeMin sec and maximum vm boot time is $_vmBootTimeMax sec" -ForegroundColor Green;
		Write-Host "----------------------------------------------------------";
		Write-Host "$_vmBootTimeCount A1 VMs in $_vmBootTimeAbsolute sec @ $_vmBootTimeAvg sec/VM" -ForegroundColor Green;
		Write-Host "----------------------------------------------------------";
		if($_vmBootFailedCount -gt 0){
			Write-Host "Failed to get boot time for $_vmBootFailedCount VMs";
			Write-Host "----------------------------------------------------------";
		}

		# Add vm average boot results to the Azure storage table
		if($storageTable -ne $null){
			try {
				# Average vm boot time
				Add-TableEntity -Table $storageTable -PartitionKey $_executionId -RowKey "AverageBootTime" -Value $_vmBootTimeAvg;
				$vmResultIndex += 1;

				# Absolute vm boot time
				Add-TableEntity -Table $storageTable -PartitionKey $_executionId -RowKey "AbsoluteBootTime" -Value $_vmBootTimeAbsolute;
				$vmResultIndex += 1;

				# Max vm boot time
				Add-TableEntity -Table $storageTable -PartitionKey $_executionId -RowKey "MaxBootTime" -Value $_vmBootTimeMax;
				$vmResultIndex += 1;

				# Max vm boot time
				Add-TableEntity -Table $storageTable -PartitionKey $_executionId -RowKey "MinBootTime" -Value $_vmBootTimeMin;
				$vmResultIndex += 1;

				# Summary
				Add-TableEntity -Table $storageTable -PartitionKey $_executionId -RowKey "Summary" -Value "$_vmBootTimeCount A1 VMs in $_vmBootTimeAbsolute sec @ $_vmBootTimeAvg sec/VM";
				$vmResultIndex += 1;

			} catch {
				Write-Verbose "Adding Azure storage table summary entry for row $vmResultIndex failed.";
				"Adding Azure storage table summary entry for row $vmResultIndex failed." | Out-File $logFilePath -Encoding ASCII -Append;
			}
		} else {
			"Azure storage table object $storageTable is null" | Out-File $logFilePath -Encoding ASCII -Append;
		}

		"----------------------------------------------------------" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		"$_vmBootTimeCount Azure A1-sized VMs cold booted in $_vmBootTimeAbsolute seconds at an average start time $_vmBootTimeAvg seconds/VM" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		"----------------------------------------------------------" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		"Minimum vm boot time is $_vmBootTimeMin sec and maximum vm boot time is $_vmBootTimeMax sec" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		"----------------------------------------------------------" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		"$_vmBootTimeCount A1 VMs in $_vmBootTimeAbsolute sec @ $_vmBootTimeAvg sec/VM" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		"----------------------------------------------------------" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		if($_vmBootFailedCount -gt 0){
			"Failed to get boot time for $_vmBootFailedCount VMs" | Out-File $vmbootResultFile -Encoding ASCII -Append;
			"----------------------------------------------------------" | Out-File $vmbootResultFile -Encoding ASCII -Append;
		}
	}
	else {
		Write-Host "Failed to get VM boot results" -ForegroundColor Red;
		"Failed to get VM boot results" | Out-File $logFilePath -Encoding ASCII -Append;
		"Failed to get VM boot results" | Out-File $vmbootResultFile -Encoding ASCII -Append;
	}

	Write-Host "VM boot storm test finished." -ForegroundColor Red;
	"VM boot storm test finished." | Out-File $logFilePath -Encoding ASCII -Append;

	Publish-AzureRmVMDscConfiguration -ResourceGroupName $resourceGroupName -ConfigurationPath $vmbootResultFile -StorageAccountName $storageAccountName -SkipDependencyDetection -Force;
	Publish-AzureRmVMDscConfiguration -ResourceGroupName $resourceGroupName -ConfigurationPath $logFilePath -StorageAccountName $storageAccountName -SkipDependencyDetection -Force -ErrorAction SilentlyContinue;
}
VMBootAll
 