@orders  =
    EXTRACT customer_id          string,
            sku           string,
			order_date	DateTime,
            product_quantity          string,
			amount_spent	float,
			latitude	string,
			longitude	string,
			payment_mode string			
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/orders/{*}.csv"   
    USING Extractors.Csv(skipFirstNRows:1, silent: true);

@customers  =
    EXTRACT customer_id          string,
            first_name           string,
			last_name	         string,
            region          string,
			state	string,
			cbgid	float,
			marital_status	string,
			education_level string,
			age	int,
			gender string
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/customers/{*}.csv"
    USING Extractors.Csv(skipFirstNRows:1, silent: true);

@rs1=
	SELECT cust.marital_status, (double)(SUM(ord.amount_spent)/1000) AS expenditure_1000
	FROM @customers AS cust
    JOIN @orders AS ord	
	ON cust.customer_id == ord.customer_id 
	GROUP BY cust.marital_status;

OUTPUT @rs1
    TO "wasb://publish@storage_account_name.blob.core.windows.net/datasets/adhoc/ADHOC_2_Expenditure_distribution_on_Marital_status.csv"	
    USING Outputters.Csv(outputHeader: true);	