// Load the http module to create an http server.
var http = require('http');
var id= Math.floor( Math.random()*1000)+1;

// Configure our HTTP server to respond with Hello World to all requests.
var server = http.createServer(function (request, response) {
  response.writeHead(200, {"Content-Type": "text/html"});
  response.write("<html><head><title>Hello wordl</title><body>")
  response.write("<h1>Hello World\n</h1>");
  response.write("id:"+id+"\n<br/>");
  response.write("time:"+Date.now()+"\n<br/>");
  response.end("</body></html>");
});

console.log("Listening on port 80");
// Listen on port 8000, IP defaults to 127.0.0.1
server.listen(80);