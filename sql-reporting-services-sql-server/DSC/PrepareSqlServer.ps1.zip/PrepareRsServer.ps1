#
# Copyright="� Microsoft Corporation. All rights reserved."
#
configuration PrepareSSRSServer
{
    param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLSAAdminAuthCreds,

	[Parameter(Mandatory)]
        [String]$CatalogMachine
    )

    Import-DscResource -ModuleName xSQLServer,xNetworking

    Node localhost
    {   
        
		xFirewall DatabaseEngineFirewallRule
		{
			Direction = "Inbound"
			Name = "Reporting-Services-HTTP-In"
			DisplayName = "Reporting Services (TCP-In)"
			Description = "Inbound rule for Reporting Services to allow TCP traffic for Report Server."
			DisplayGroup = "SQL Server"
			State = "Enabled"
			Access = "Allow"
			Protocol = "TCP"
			LocalPort = "80"
			Ensure = "Present"
		}
    

		xSQLServerRSConfig RSServer
		{
			InstanceName = "MSSQLSERVER"
			RSSQLServer = $CatalogMachine
			RSSQLInstanceName = "MSSQLSERVER"
			SQLAdminCredential = $SQLSAAdminAuthCreds
		}
       
    }
}