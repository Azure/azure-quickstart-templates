# Description

This resource is used to work with SharePoint Property Bags at the farm level.
The account that runs this resource must be a farm administrator.
