# Description

This resource is responsible for managing the search file types in the search
service application. You can create new file types, change existing types and
remove existing file types.
