﻿[DscLocalConfigurationManager()]
Configuration ConfigureLCMforAAPull
{
    Settings
    {
        RebootNodeIfNeeded = $true
        ActionAfterReboot = 'ContinueConfiguration'
    }

}