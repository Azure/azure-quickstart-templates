﻿[DscLocalConfigurationManager()]
Configuration DCLCMConfig
{
    Settings
    {
        RebootNodeIfNeeded = $true
        ActionAfterReboot = 'ContinueConfiguration'
    }

}