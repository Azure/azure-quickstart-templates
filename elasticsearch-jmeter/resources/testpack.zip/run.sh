#!/bin/bash
/opt/jmeter/apache-jmeter-2.13/bin/jmeter -n -r -t /opt/jmeter/testplan5nodes.jmx -Grun.properties
